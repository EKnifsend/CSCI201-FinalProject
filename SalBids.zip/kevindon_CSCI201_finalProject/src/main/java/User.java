public class User {
	public String username;
	public String password;
	public String firstName;
	public String lastName;
	public int balance;
	
	User(String firstName, String lastName, int balance){
		this.firstName = firstName;
		this.lastName = lastName;
		this.balance = balance;
	}
	User(){};
}