var socket;
function connectToServer(){
    console.log("INSIDE OF: connectToServer()");
    socket = new WebSocket("ws://localhost:8080/kevindon_CSCI201_finalProject/ws");
    socket.onopen = function(event){
        // document.getElementById("mychat").innerHTML += "Connected" + "<br />";
    }
    // receives message from server
    socket.onmessage = function(event){
		document.getElementById("chatContent").innerHTML += event.data + "<br />";
		$("#chatContent").scrollTop($("#chatContent")[0].scrollHeight);
	}
	socket.onclose = function(event){
		// document.getElementById("mychat").innerHTML += "Disconnected";
	}
}

function displayProfile(userID){
	
	$.ajax({
		
		url : 'ProfileServlet',
		type: 'POST',
		dataType: 'text',
		data : {
			userID : userID,
		},
		success: function(responseText){
			console.log(responseText);
			
			// returns object where object["user"] gives user info and object["bets"] gives bets info
			var object = JSON.parse(responseText);
			console.log(object);
			
			var user = object["user"];
			var bets = object["bets"];
			
			var namesHTML = user["firstName"] + " " + user["lastName"];
			$(".modal-title").html(namesHTML);
			
			const formatter = new Intl.NumberFormat('en-US', {
				  style: 'currency',
				  currency: 'USD',
			});
			
	
			if(bets.length == 0){
				$(".modal-body").html("<h4>No Bets Placed</h4>");
			}else{
				var betsHTML = "";
				betsHTML = "<div><h3>Current Bets: </h3></div>";
				for(var i = 0; i < bets.length ; i++){
					betsHTML += "<div class=\"betInfo\">";
					betsHTML += "<h5 style='display: inline;'>";
					betsHTML += bets[i]["teamName"] + "</h5>";
					betsHTML += "<h5 style='display: inline; float:right;'>Amount Betted: ";
					betsHTML += bets[i]["amount"] + "</h5>";
					betsHTML += "</div>";
				}
				
				$(".modal-body").html(betsHTML);
			}
	
		},

	});
}

// send message to server
function sendMessage(){
	var cookie = getCookie("username");
	var userID = getCookie("userID");
	
	// get date
	var date = new Date().toLocaleString();
	
	var message = "<div class='message'>";
	message += "<div class='row'><div class='col'><h4 onclick='displayProfile(" + userID + ")' class='username'>";
	message += cookie;
	message += "</h4></div><div class='col' style='text-align: right;'";
	message += "<span>";
	message += date;
	message += "</span></div></div>";
	message += document.chatform.message.value;
	message += "</div>";
	socket.send(message);
	return false;
	
}