function setCookie(cname,cvalue,exdays) {
  const d = new Date();
  d.setTime(d.getTime() + (exdays*24*60*60*1000));
  let expires = "expires=" + d.toUTCString();
  document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
}

function getCookie(cname) {
  let name = cname + "=";
  let decodedCookie = decodeURIComponent(document.cookie);
  let ca = decodedCookie.split(';');
  for(let i = 0; i < ca.length; i++) {
    let c = ca[i];
    while (c.charAt(0) == ' ') {
      c = c.substring(1);
    }
    if (c.indexOf(name) == 0) {
      return c.substring(name.length, c.length);
    }
  }
  return "";
}

function checkCookie() {
  let user = getCookie("username");
  if (user != "") {
    alert("Welcome again " + user);
  } else {
     user = prompt("Please enter your name:","");
     if (user != "" && user != null) {
       setCookie("username", user, 30);
     }
  }
}

function deleteCookie(){
	document.cookie = "userID=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;";
	location.href = '/kevindon_CSCI201_finalProject/index.html';
}

function executeBets(){
	var cookie = getCookie("userID");
	
	if(cookie != null || cookie != ""){
		console.log("execute bets; cookie: " + cookie);	
		$.ajax({
			url : 'ExecuteBetServlet',
			type: 'POST',
			dataType: 'text',
			data : {
				userID : cookie,
			},
			success : function(responseText) {
				// console.log(responseText);
				// alert(responseText);
				$("#resultModal").modal("show");
				$("#resultModal .modal-body").html(responseText);
				$("#resultModal").on("hide.bs.modal", function () {
    				// put your default event here
    				location.reload();
				});
				console.log("execute Bets()");
				
			}
		});
	}else{
		console.log("no userID");
	}
	
}

function display(){
	var xhttp = new XMLHttpRequest();
	xhttp.open("GET", "DisplayServlet", true);
	xhttp.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
	xhttp.onload = function() {
		console.log(this.responseText);
		console.log(JSON.parse(this.responseText));
		var schedule = JSON.parse(this.responseText);
		var list = "";
		for(var i = 0; i < schedule.length; i++){
			// update teamIDs
			teamNames[schedule[i]["homeTeam"]["teamID"]] = schedule[i]["homeTeam"]["teamName"];
			teamNames[schedule[i]["awayTeam"]["teamID"]] = schedule[i]["awayTeam"]["teamName"];
			
			// update matchupIDs (in order of object; 1-based index)
			matchupIDs[schedule[i]["homeTeam"]["teamID"]] = i + 1;
			matchupIDs[schedule[i]["awayTeam"]["teamID"]] = i + 1;
			
			// update div
			/* Concept 
				- Each input div has teamID
				- Each place bet button has value of teamID so we can access the appropriate input div to get the amount
			*/
			list += "<div class=\"container matchupDiv\">";
			list += "<div class=\"row\">";
			list += "<div class=\"column\" style=\"text-align:left\"><h1>";
			list += schedule[i]["homeTeam"]["teamName"] + "</h1></br><label><h3>MoneyLine: ";
			list += schedule[i]["homeLine"] + "</h3></label><form name=\"bet\">"
			list += "<div data-toggle=\"validator\" class=\"form-group\">";
			list += "<input id=" + "'" + schedule[i]["homeTeam"]["teamID"] + "'" + "class=\"form-control\" type=\"number\" name=\"amount\" required /></br>";
			list += "<button type=\"submit\" class=\"bet btn btn-danger\" value=" + "'" + schedule[i]["homeTeam"]["teamID"] + "'" + ">Place Bet</button>";
			list += "</div>";
			list += "</form></div><div class=\"column\" style=\"text-align:right\"><h1>";
			list += schedule[i]["awayTeam"]["teamName"] + "</h1></br><label><h3>MoneyLine: ";
			list += schedule[i]["awayLine"] + "</h3></label><form data-toggle=\"validator\" name=\"bet\">";
			list += "<div class=\"form-group\">";
			list += "<input id=" + "'" + schedule[i]["awayTeam"]["teamID"] + "'" + "class=\"form-control ml-auto\" type=\"number\" name=\"amount\" required /></br>";
			list += "<button type=\"submit\" class=\"bet btn btn-danger\" value=" + "'" + schedule[i]["awayTeam"]["teamID"] + "'" + ">Place Bet</button>";
			list += "</div>";
			list += "</form></div></div>";
			list += "</div>";
			list += "</div>";
			
		}
		document.getElementById("games").innerHTML = list; 
	}
	xhttp.send();
}


// return leading zeros (i.e. if size = 2, and num = 2 => 02)
function pad(num, size) {
    num = num.toString();
    while (num.length < size) num = "0" + num;
    return num;
}

// return timer
// date format: "Jan 5, 2024 15:20:25"
function countDownTimer(date, index){
	
	// var times = ["Nov 27, 2022 17:25:00", "Nov 27, 2022 17:28:00", "Nov 27, 2022 17:31:00"];
	
	var dateObject = new Date(date);
	// Set the date we're counting down to
	var countDownDate = dateObject.getTime();
	
	// Update the count down every 1 second
	var x = setInterval(function() {

		// Get today's date and time
		var now = new Date().getTime();
	    
	    // Find the distance between now and the count down date
	  	var distance = countDownDate - now;
	    
	    // Time calculations for days, hours, minutes and seconds
		var days = Math.floor(distance / (1000 * 60 * 60 * 24));
		var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
		var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
		var seconds = Math.floor((distance % (1000 * 60)) / 1000);
	 
		// Output the result in an element with id="demo"
		document.getElementById("timer").innerHTML = pad(minutes,1) + ":" + pad(seconds,2);
		
		// If the count down is over, write some text 
		if (distance < 0) {
			clearInterval(x);
			document.getElementById("timer").innerHTML = "EXPIRED";
			executeBets();
			
			// location.reload();
		}
	
	}, 1000);
}

